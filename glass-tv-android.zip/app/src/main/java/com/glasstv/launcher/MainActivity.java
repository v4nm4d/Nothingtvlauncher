package com.glasstv.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String API_HOST = "api.waktusolat.app";
    private static final int ICON_PX = 96;

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.setBackgroundColor(Color.BLACK);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidTV");
        setContentView(web);
        web.requestFocus();
        web.loadUrl(START_URL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        if (web != null) web.evaluateJavascript("window.__resume&&window.__resume()", null);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home button pressed while the launcher is already open.
        if (web != null) web.evaluateJavascript("window.__goHome&&window.__goHome()", null);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // A launcher never exits; let the page close menus or return to Home.
        if (web != null) web.evaluateJavascript("window.__back&&window.__back()", null);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("AndroidTV");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    /** Functions the page calls as window.AndroidTV.* */
    private class Bridge {

        @JavascriptInterface
        public String getApps() {
            PackageManager pm = getPackageManager();
            List<ResolveInfo> found = new ArrayList<>();
            found.addAll(query(pm, Intent.CATEGORY_LEANBACK_LAUNCHER));
            found.addAll(query(pm, Intent.CATEGORY_LAUNCHER));

            Set<String> seen = new HashSet<>();
            JSONArray out = new JSONArray();
            for (ResolveInfo ri : found) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("id", pkg);
                    o.put("name", String.valueOf(ri.loadLabel(pm)));
                    o.put("cat", categoryOf(ri, pkg));
                    o.put("icon", "data:image/png;base64," + iconPng(ri.loadIcon(pm)));
                    out.put(o);
                } catch (Exception ignored) {
                    // skip an app whose icon or label cannot be read
                }
            }
            return out.toString();
        }

        @JavascriptInterface
        public void launch(final String pkg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PackageManager pm = getPackageManager();
                    Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
                    if (i == null) i = pm.getLaunchIntentForPackage(pkg);
                    if (i == null) return;
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        startActivity(i);
                    } catch (Exception ignored) {
                        // app refused to start
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSettings(final String kind) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String[] tries;
                    if ("wifi".equals(kind)) {
                        tries = new String[]{Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS};
                    } else if ("inputs".equals(kind)) {
                        tries = new String[]{"android.settings.INPUT_METHOD_SETTINGS", Settings.ACTION_SETTINGS};
                    } else {
                        tries = new String[]{Settings.ACTION_SETTINGS};
                    }
                    for (String action : tries) {
                        try {
                            Intent i = new Intent(action);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                            return;
                        } catch (Exception ignored) {
                            // try the next action
                        }
                    }
                }
            });
        }

        /** Fetches JSON from the prayer time API only, then calls window.__nativeCb(id, ok, body). */
        @JavascriptInterface
        public void httpGet(final String url, final int id) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    boolean ok = false;
                    String body;
                    HttpURLConnection c = null;
                    try {
                        Uri u = Uri.parse(url);
                        if (!"https".equals(u.getScheme()) || !API_HOST.equals(u.getHost())) {
                            throw new SecurityException("blocked host");
                        }
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(20000);
                        c.setRequestProperty("Accept", "application/json");
                        int code = c.getResponseCode();
                        if (code < 200 || code >= 300) throw new RuntimeException("http " + code);
                        InputStream in = c.getInputStream();
                        ByteArrayOutputStream buf = new ByteArrayOutputStream();
                        byte[] chunk = new byte[8192];
                        int n;
                        while ((n = in.read(chunk)) > 0) buf.write(chunk, 0, n);
                        body = buf.toString("UTF-8");
                        ok = true;
                    } catch (Exception e) {
                        body = String.valueOf(e.getMessage());
                    } finally {
                        if (c != null) c.disconnect();
                    }
                    final String js = "window.__nativeCb&&window.__nativeCb(" + id + "," + ok + ","
                            + JSONObject.quote(body) + ")";
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web != null) web.evaluateJavascript(js, null);
                        }
                    });
                }
            }).start();
        }
    }

    private static List<ResolveInfo> query(PackageManager pm, String category) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(category);
        return pm.queryIntentActivities(i, 0);
    }

    private static String categoryOf(ResolveInfo ri, String pkg) {
        String key = (pkg + " " + ri.activityInfo.name).toLowerCase(Locale.ROOT);
        if (Build.VERSION.SDK_INT >= 26) {
            int cat = ri.activityInfo.applicationInfo.category;
            if (cat == ApplicationInfo.CATEGORY_VIDEO) return "video";
            if (cat == ApplicationInfo.CATEGORY_AUDIO) return "music";
        }
        if (key.contains("music") || key.contains("spotify") || key.contains("audio") || key.contains("podcast")) {
            return "music";
        }
        if (key.contains("video") || key.contains("netflix") || key.contains("youtube") || key.contains("disney")
                || key.contains("stremio") || key.contains("tv") || key.contains("player") || key.contains("movie")) {
            return "video";
        }
        return "utilities";
    }

    private static String iconPng(Drawable d) {
        Bitmap bmp = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        d.setBounds(0, 0, ICON_PX, ICON_PX);
        d.draw(canvas);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        bmp.recycle();
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }
}
