# Glass TV launcher (Android TV APK)

A WebView launcher. The interface is `app/src/main/assets/index.html`.
It lists the apps installed on the TV, shows their own icons, and launches them.
Prayer times come from api.waktusolat.app, fetched by the app (not the page).

## Build the APK (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder.
2. Open the repository's Actions tab and run "Build APK" (it also runs on every push).
3. When it finishes, download the `GlassTV-apk` artifact. The APK is inside.

## Build on your own computer
Install Android Studio (or JDK 17 + Android SDK 34), open this folder, then run:
    ./gradlew assembleRelease
The APK is written to app/build/outputs/apk/release/app-release-unsigned.apk or app-release.apk.
It is signed with the debug key so it installs directly.

## Install
- Android TV / Google TV: enable Developer options, then use `adb connect <tv-ip>` and
  `adb install app-release.apk`, or copy it to a USB drive and open it with a file manager.
- To use it as the Home screen, Android TV asks which launcher to use when you press Home
  after install. Some TVs hide this choice; use a "Home app" setting or a helper app.

## Notes
- Fonts (Doto, Outfit) load from Google Fonts. Offline, the page falls back to system fonts.
- Controls: D-pad moves, Center selects (hold to arrange or open options), Back closes menus.
- The Inputs button opens system settings (Android gives apps no direct input picker).
- The glass and blur effects can be slow on low-end TVs. Set App icons to Monochrome in
  Customize to turn off the lens and blur on tiles if it stutters.
